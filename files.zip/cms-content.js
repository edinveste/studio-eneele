// cms-content.js
// Lê data/servicos.json e data/resultados.json e monta os cards do site
// automaticamente. Isso permite que o conteúdo seja editado pelo painel
// /admin (Decap CMS) sem precisar mexer no HTML.

(function () {
  const WHATSAPP_NUMERO = "5511987343215";

  const ICONES = {
    sobrancelha: '<path d="M3 15c2-6 6-8 9-8s7 2 9 8" /><path d="M6 15h12" />',
    gota: '<path d="M12 3c3 3 5 6 5 9a5 5 0 0 1-10 0c0-3 2-6 5-9z" />',
    linhas: '<path d="M4 12h16M4 8h10M4 16h10" />',
    ondulacao: '<path d="M4 16c2-7 16-7 16 0" /><path d="M6 12c1-2 3-3 6-3s5 1 6 3" />',
    cilios: '<path d="M2 12c3-4 7-6 10-6s7 2 10 6c-3 4-7 6-10 6s-7-2-10-6z" /><circle cx="12" cy="12" r="2.4" />',
    unha: '<path d="M8 3v6c0 2 1.5 3 4 3s4-1 4-3V3" /><path d="M12 12v9" />'
  };

  function iconeSvg(nome) {
    const path = ICONES[nome] || ICONES.sobrancelha;
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">${path}</svg>`;
  }

  function waLink(texto) {
    return `https://wa.me/${WHATSAPP_NUMERO}?text=${encodeURIComponent(texto)}`;
  }

  function renderServicos(dados) {
    const categorias = ["sobrancelhas", "cilios", "unhas"];
    categorias.forEach((cat) => {
      const grid = document.getElementById("grid-" + cat);
      if (!grid) return;
      const itens = dados[cat] || [];
      grid.innerHTML = itens
        .map(
          (item) => `
        <div class="service-card">
          <div class="icon">${iconeSvg(item.icone)}</div>
          <h3>${item.titulo || ""}</h3>
          <p>${item.descricao || ""}</p>
          <a href="${waLink(item.whatsapp_texto || "")}" target="_blank" rel="noopener">Agendar</a>
        </div>`
        )
        .join("");
    });
  }

  function renderResultados(dados) {
    const categorias = ["sobrancelhas", "cilios", "unhas"];
    categorias.forEach((cat) => {
      const frame = document.querySelector(`.ba-frame[data-bapanel="${cat}"]`);
      if (!frame) return;
      const itens = (dados[cat] || []).filter((i) => i.antes || i.depois);
      const dotsWrap = frame.querySelector(".ba-dots");
      const afterImg = frame.querySelector(".ba-after img");
      const beforeImg = frame.querySelector(".ba-before img");

      if (itens.length === 0) {
        frame.style.display = "none";
        return;
      }
      frame.style.display = "";

      let indice = 0;
      function mostrar(i) {
        indice = i;
        if (afterImg) afterImg.src = itens[i].depois || "";
        if (beforeImg) beforeImg.src = itens[i].antes || "";
        if (dotsWrap) {
          [...dotsWrap.children].forEach((dot, di) =>
            dot.classList.toggle("is-active", di === i)
          );
        }
      }

      if (dotsWrap) {
        dotsWrap.innerHTML = "";
        if (itens.length > 1) {
          itens.forEach((_, i) => {
            const dot = document.createElement("button");
            dot.className = "ba-dot";
            dot.setAttribute("aria-label", "Ver exemplo " + (i + 1));
            dot.addEventListener("click", () => mostrar(i));
            dotsWrap.appendChild(dot);
          });
        }
      }

      mostrar(0);
    });
  }

  Promise.all([
    fetch("data/servicos.json").then((r) => r.json()),
    fetch("data/resultados.json").then((r) => r.json())
  ])
    .then(([servicos, resultados]) => {
      renderServicos(servicos);
      renderResultados(resultados);
    })
    .catch((err) => console.error("Erro ao carregar conteúdo do CMS:", err));
})();
